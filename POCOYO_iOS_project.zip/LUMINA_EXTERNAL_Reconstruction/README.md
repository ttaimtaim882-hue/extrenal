# POCOYO — iOS SwiftUI reconstruction

This ZIP contains a renamed SwiftUI interface project based on the supplied reconstruction starter.

- App display name: POCOYO
- Minimum iOS deployment target: 16.0 (intended to run on newer iOS versions, including iOS 26.x, subject to device/build/signing checks)
- SwiftUI interface and bundled assets/localizations retained

## Build
Open `LUMINAExternal.xcodeproj` in Xcode, select a valid signing team, then build.

## Limitations
The original compiled implementation cannot be reconstructed exactly from an IPA. Injection, exploit, game modification, and server-side functionality are not implemented. The GitHub Actions JSONDecodeError is not fixed here because the workflow YAML/scripts that produced it were not included in this ZIP; it needs the failing workflow log and script.
