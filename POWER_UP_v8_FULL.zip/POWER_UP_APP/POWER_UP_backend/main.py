"""
POWER UP — backend (FastAPI)
- Serves the website folder (index.html + admin.html) on the same address
- Stores keys, site settings (texts, buttons, maintenance, colors, links), uploads
Run:  uvicorn main:app --host 0.0.0.0 --port 8000
"""
import hashlib
import json
import os
import re
import secrets
import string
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import Body, Depends, FastAPI, File, Header, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("DATA_DIR", BASE_DIR / "data"))
WEBSITE_DIR = Path(os.getenv("WEBSITE_DIR", BASE_DIR.parent / "website"))
UPLOAD_DIR = DATA_DIR / "uploads"
DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

KEYS_FILE = DATA_DIR / "keys.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
FEATURES_FILE = DATA_DIR / "features.json"
PRIVATE_FILE = DATA_DIR / "private.json"
SELLERS_FILE = DATA_DIR / "sellers.json"
SESSIONS_FILE = DATA_DIR / "seller_sessions.json"

DEFAULT_ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "PS-88-88")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "200"))

app = FastAPI(title="POWER UP API", version="2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ───────── storage helpers ─────────
def _load(path: Path, fallback):
    if not path.exists():
        return fallback
    try:
        return json.loads(path.read_text("utf-8"))
    except Exception:
        return fallback


def _save(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")
    tmp.replace(path)


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def parse_iso(s: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None


def admin_password() -> str:
    return _load(PRIVATE_FILE, {}).get("admin_password") or DEFAULT_ADMIN_PASSWORD


def verify_admin(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    key = x_api_key or (authorization.replace("Bearer ", "") if authorization else None)
    extra = os.getenv("ADMIN_API_KEY")
    if not key or not (secrets.compare_digest(key, admin_password()) or (extra and secrets.compare_digest(key, extra))):
        raise HTTPException(status_code=401, detail="Invalid admin code")
    return True


# ───────── models ─────────
class KeyCreate(BaseModel):
    days: int = 7
    hours: int = 0
    note: Optional[str] = ""
    prefix: Optional[str] = "POWER"
    max_devices: int = 1


class ActivateRequest(BaseModel):
    license_key: str
    device_id: Optional[str] = None
    device_name: Optional[str] = None


class PasswordBody(BaseModel):
    password: str


def gen_code(prefix: str) -> str:
    chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    p = "".join(c for c in (prefix or "POWER").upper() if c.isalnum())[:10] or "POWER"
    seg = lambda: "".join(secrets.choice(chars) for _ in range(4))
    return f"{p}-{seg()}-{seg()}-{seg()}"


# ───────── public ─────────
@app.get("/api/health")
def health():
    return {"status": "ok", "service": "POWERUP", "keys_count": len(_load(KEYS_FILE, []))}


@app.get("/api/settings")
def get_settings():
    return _load(SETTINGS_FILE, {})


@app.post("/api/activate")
def activate_key(req: ActivateRequest):
    keys = _load(KEYS_FILE, [])
    code = req.license_key.strip().upper()
    if not code:
        raise HTTPException(status_code=400, detail="Enter your code first")
    k = next((x for x in keys if x["code"].upper() == code), None)
    if not k:
        raise HTTPException(status_code=400, detail="Invalid key")

    now = now_utc()
    if k.get("activatedAt") and k.get("expiresAt"):
        exp = parse_iso(k["expiresAt"])
        if exp and exp < now:
            raise HTTPException(status_code=400, detail="Key has expired")

    devices = k.get("devices", [])
    device_id = req.device_id or "unknown"
    if not any(d.get("id") == device_id for d in devices):
        if len(devices) >= int(k.get("max_devices", 1)):
            raise HTTPException(status_code=400, detail=f"Device limit reached ({k.get('max_devices', 1)} max)")
        devices.append({"id": device_id, "name": req.device_name or "Unknown", "registeredAt": iso(now)})
        k["devices"] = devices

    if not k.get("activatedAt"):
        k["activatedAt"] = iso(now)
        hours = int(k.get("hours", 0) or 0)
        days = int(k.get("days", 7))
        if hours > 0:
            k["expiresAt"] = iso(now + timedelta(hours=hours))
        else:
            k["expiresAt"] = None if days == 0 else iso(now + timedelta(days=days))

    _save(KEYS_FILE, keys)
    return {
        "status": "success",
        "key": k["code"],
        "expires_at": k.get("expiresAt") or "",
        "activated_at": k.get("activatedAt"),
        "days": k.get("days", 7),
        "hours": k.get("hours", 0),
        "max_devices": k.get("max_devices", 1),
        "devices_used": len(k.get("devices", [])),
        "token": f"tok_{k['code']}",
    }


@app.post("/api/features")
def features(body: Dict[str, Any] = Body(...)):
    code = str(body.get("key", "")).strip().upper()
    keys = _load(KEYS_FILE, [])
    if not code or not any(k["code"].upper() == code for k in keys):
        raise HTTPException(status_code=401, detail="Invalid key")
    store = _load(FEATURES_FILE, {})
    state = store.get(code, {})
    allowed = {"moco", "aimbot", "aimlag", "freeze_fire", "freeze_scope", "icewall", "auto_revive", "marker"}
    if body.get("feature") in allowed and "value" in body:
        state[body["feature"]] = str(body["value"])
    for k in allowed:
        if k in body:
            state[k] = str(body[k])
    store[code] = state
    _save(FEATURES_FILE, store)
    return {"status": "ok", "features": state}


# ───────── admin ─────────
@app.post("/api/admin/login")
def admin_login(body: PasswordBody):
    if not secrets.compare_digest(body.password.strip(), admin_password()):
        raise HTTPException(status_code=401, detail="Invalid admin code")
    return {"ok": True}


@app.post("/api/admin/password", dependencies=[Depends(verify_admin)])
def admin_change_password(body: PasswordBody):
    p = body.password.strip()
    if len(p) < 4:
        raise HTTPException(status_code=400, detail="Too short")
    priv = _load(PRIVATE_FILE, {})
    priv["admin_password"] = p
    _save(PRIVATE_FILE, priv)
    return {"ok": True}


@app.put("/api/settings", dependencies=[Depends(verify_admin)])
def put_settings(body: Dict[str, Any] = Body(...)):
    _save(SETTINGS_FILE, body)
    return {"ok": True}


@app.post("/api/upload", dependencies=[Depends(verify_admin)])
async def upload(file: UploadFile = File(...)):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".mp4", ".mov", ".webm", ".m4v"}:
        raise HTTPException(status_code=400, detail="File type not allowed")
    name = f"{uuid.uuid4().hex}{ext}"
    dest = UPLOAD_DIR / name
    size = 0
    with dest.open("wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_UPLOAD_MB * 1024 * 1024:
                out.close()
                dest.unlink(missing_ok=True)
                raise HTTPException(status_code=413, detail=f"Max {MAX_UPLOAD_MB}MB")
            out.write(chunk)
    return {"url": f"/uploads/{name}"}


@app.get("/api/keys", dependencies=[Depends(verify_admin)])
def list_keys():
    names = {x["id"]: x["username"] for x in _load(SELLERS_FILE, [])}
    return [client_key(k, names) for k in _load(KEYS_FILE, [])]


@app.post("/api/keys", dependencies=[Depends(verify_admin)])
def create_key(body: KeyCreate):
    keys = _load(KEYS_FILE, [])
    code = gen_code(body.prefix or "POWER")
    while any(k["code"] == code for k in keys):
        code = gen_code(body.prefix or "POWER")
    new_key = {
        "code": code,
        "days": 0 if body.hours > 0 else max(0, body.days),
        "hours": max(0, min(720, body.hours)),
        "note": body.note or "",
        "max_devices": max(1, body.max_devices),
        "devices": [],
        "createdAt": iso(now_utc()),
        "activatedAt": None,
        "expiresAt": None,
    }
    keys.append(new_key)
    _save(KEYS_FILE, keys)
    return new_key


@app.delete("/api/keys/{code}", dependencies=[Depends(verify_admin)])
def delete_key(code: str):
    keys = [k for k in _load(KEYS_FILE, []) if k["code"].upper() != code.upper()]
    _save(KEYS_FILE, keys)
    return {"status": "deleted", "code": code}


# ───────── sellers ─────────
# Same prices as the live server (src/lib/seller-plans.ts). Admin overrides them in settings["prices"].
DEFAULT_PLANS = [
    {"id": "d30", "days": 30, "hours": 0, "price": 3.5},
    {"id": "d15", "days": 15, "hours": 0, "price": 2.4},
    {"id": "d7", "days": 7, "hours": 0, "price": 1.5},
    {"id": "d3", "days": 3, "hours": 0, "price": 0.8},
    {"id": "d1", "days": 1, "hours": 0, "price": 0.3},
    {"id": "h12", "days": 0, "hours": 12, "price": 0.25},
    {"id": "h6", "days": 0, "hours": 6, "price": 0.2},
    {"id": "h3", "days": 0, "hours": 3, "price": 0.12},
    {"id": "h1", "days": 0, "hours": 1, "price": 0.06},
]
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")


def resolve_plans():
    saved = _load(SETTINGS_FILE, {}).get("prices") or []
    out = []
    for p in DEFAULT_PLANS:
        o = next((x for x in saved if isinstance(x, dict) and x.get("id") == p["id"]), None)
        price = p["price"]
        try:
            if o is not None and float(o.get("price")) >= 0:
                price = round(float(o.get("price")), 2)
        except Exception:
            pass
        out.append({**p, "price": price, "off": bool(o and o.get("off"))})
    return out


def hash_password(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100_000).hex()


def cents(v) -> int:
    return int(round(float(v) * 100))


def client_key(k, names=None):
    out = dict(k)
    out.setdefault("hours", 0)
    out["seller"] = (names or {}).get(k.get("seller_id"), "") if k.get("seller_id") else ""
    out["price"] = float(k.get("price") or 0)
    return out


def current_seller(request: Request):
    t = (request.headers.get("x-seller-token") or "").strip()
    if not t:
        raise HTTPException(status_code=401, detail="Please log in again")
    sid = _load(SESSIONS_FILE, {}).get(hashlib.sha256(t.encode()).hexdigest())
    s = next((x for x in _load(SELLERS_FILE, []) if x["id"] == sid), None) if sid else None
    if not s:
        raise HTTPException(status_code=401, detail="Please log in again")
    return s


def drop_keys(codes):
    codes = {c.upper() for c in codes}
    _save(KEYS_FILE, [k for k in _load(KEYS_FILE, []) if k["code"].upper() not in codes])
    feats = _load(FEATURES_FILE, {})
    _save(FEATURES_FILE, {c: v for c, v in feats.items() if c.upper() not in codes})


@app.post("/api/seller/login")
def seller_login(body: Dict[str, Any] = Body(...)):
    username = str(body.get("username", "")).strip().lower()
    password = str(body.get("password", ""))
    if not username or not password:
        raise HTTPException(status_code=400, detail="Enter username and password")
    s = next((x for x in _load(SELLERS_FILE, []) if x["username"] == username), None)
    if not s or not secrets.compare_digest(hash_password(password, s["pass_salt"]), s["pass_hash"]):
        raise HTTPException(status_code=401, detail="Wrong username or password")
    token = secrets.token_hex(32)
    sessions = _load(SESSIONS_FILE, {})
    sessions[hashlib.sha256(token.encode()).hexdigest()] = s["id"]
    _save(SESSIONS_FILE, sessions)
    return {"token": token, "username": s["username"], "balance": s["balance"]}


@app.post("/api/seller/logout")
def seller_logout(request: Request):
    current_seller(request)
    t = (request.headers.get("x-seller-token") or "").strip()
    sessions = _load(SESSIONS_FILE, {})
    sessions.pop(hashlib.sha256(t.encode()).hexdigest(), None)
    _save(SESSIONS_FILE, sessions)
    return {"ok": True}


@app.get("/api/seller/me")
def seller_me(request: Request):
    s = current_seller(request)
    plans = [{k: v for k, v in p.items() if k != "off"} for p in resolve_plans() if not p["off"]]
    return {"username": s["username"], "balance": s["balance"], "plans": plans}


@app.get("/api/seller/keys")
def seller_keys(request: Request):
    s = current_seller(request)
    mine = [client_key(k) for k in _load(KEYS_FILE, []) if k.get("seller_id") == s["id"]]
    return sorted(mine, key=lambda k: k.get("createdAt", ""), reverse=True)


@app.post("/api/seller/keys")
def seller_make_keys(request: Request, body: Dict[str, Any] = Body(...)):
    s = current_seller(request)
    plan = next((p for p in resolve_plans() if p["id"] == body.get("plan") and not p["off"]), None)
    if not plan:
        raise HTTPException(status_code=400, detail="Choose a plan")
    try:
        count = max(1, min(50, int(body.get("count", 1))))
    except Exception:
        count = 1
    cost = cents(plan["price"]) * count
    sellers = _load(SELLERS_FILE, [])
    me = next(x for x in sellers if x["id"] == s["id"])
    if cents(me["balance"]) < cost:
        raise HTTPException(status_code=402, detail="Not enough balance")
    me["balance"] = (cents(me["balance"]) - cost) / 100
    keys = _load(KEYS_FILE, [])
    prefix = _load(SETTINGS_FILE, {}).get("keyPrefix") or "POWER"
    made = []
    for _ in range(count):
        code = gen_code(prefix)
        while any(k["code"] == code for k in keys):
            code = gen_code(prefix)
        k = {"code": code, "days": plan["days"], "hours": plan["hours"], "note": me["username"], "max_devices": 1,
             "devices": [], "createdAt": iso(now_utc()), "activatedAt": None, "expiresAt": None,
             "seller_id": me["id"], "price": plan["price"]}
        keys.append(k)
        made.append(client_key(k))
    _save(KEYS_FILE, keys)
    _save(SELLERS_FILE, sellers)
    return {"keys": made, "balance": me["balance"]}


@app.delete("/api/seller/keys")
def seller_delete_all(request: Request):
    s = current_seller(request)
    codes = [k["code"] for k in _load(KEYS_FILE, []) if k.get("seller_id") == s["id"]]
    drop_keys(codes)
    return {"status": "deleted", "count": len(codes)}


@app.delete("/api/seller/keys/{code}")
def seller_delete_one(code: str, request: Request):
    s = current_seller(request)
    if not any(k["code"].upper() == code.upper() and k.get("seller_id") == s["id"] for k in _load(KEYS_FILE, [])):
        raise HTTPException(status_code=404, detail="Not found")
    drop_keys([code])
    return {"status": "deleted", "code": code}


@app.delete("/api/keys", dependencies=[Depends(verify_admin)])
def delete_all_keys():
    _save(KEYS_FILE, [])
    _save(FEATURES_FILE, {})
    return {"status": "deleted"}


@app.get("/api/sellers", dependencies=[Depends(verify_admin)])
def list_sellers():
    keys = _load(KEYS_FILE, [])
    out = []
    for x in _load(SELLERS_FILE, []):
        mine = [k for k in keys if k.get("seller_id") == x["id"]]
        out.append({"id": x["id"], "username": x["username"], "balance": x["balance"], "createdAt": x["createdAt"],
                    "keys": len(mine), "used": len([k for k in mine if k.get("activatedAt")])})
    return {"plans": resolve_plans(), "sellers": out}


@app.post("/api/sellers", dependencies=[Depends(verify_admin)])
def add_seller(body: Dict[str, Any] = Body(...)):
    username = str(body.get("username", "")).strip().lower()
    password = str(body.get("password", ""))
    try:
        balance = max(0.0, round(float(body.get("balance") or 0), 2))
    except Exception:
        balance = 0.0
    if not USERNAME_RE.match(username):
        raise HTTPException(status_code=400, detail="Username: 3-32 letters or numbers, no spaces")
    if not 4 <= len(password) <= 100:
        raise HTTPException(status_code=400, detail="Password too short")
    sellers = _load(SELLERS_FILE, [])
    if any(x["username"] == username for x in sellers):
        raise HTTPException(status_code=409, detail="Username already used")
    salt = secrets.token_hex(16)
    s = {"id": str(uuid.uuid4()), "username": username, "pass_salt": salt, "pass_hash": hash_password(password, salt),
         "balance": balance, "createdAt": iso(now_utc())}
    sellers.append(s)
    _save(SELLERS_FILE, sellers)
    return {"id": s["id"], "username": username, "balance": balance, "createdAt": s["createdAt"], "keys": 0, "used": 0}


def _drop_sessions(keep):
    _save(SESSIONS_FILE, {h: sid for h, sid in _load(SESSIONS_FILE, {}).items() if keep(sid)})


@app.delete("/api/sellers", dependencies=[Depends(verify_admin)])
def delete_all_sellers():
    _save(SELLERS_FILE, [])
    _save(SESSIONS_FILE, {})
    return {"status": "deleted"}


@app.delete("/api/sellers/{sid}", dependencies=[Depends(verify_admin)])
def delete_seller(sid: str):
    _save(SELLERS_FILE, [x for x in _load(SELLERS_FILE, []) if x["id"] != sid])
    _drop_sessions(lambda x: x != sid)
    return {"status": "deleted", "id": sid}


@app.post("/api/sellers/{sid}/balance", dependencies=[Depends(verify_admin)])
def seller_balance(sid: str, body: Dict[str, Any] = Body(...)):
    try:
        amount = round(float(body.get("amount") or 0), 2)
    except Exception:
        amount = -1
    if amount < 0 or amount > 1_000_000:
        raise HTTPException(status_code=400, detail="Bad amount")
    sellers = _load(SELLERS_FILE, [])
    s = next((x for x in sellers if x["id"] == sid), None)
    if not s:
        raise HTTPException(status_code=404, detail="Not found")
    mode = body.get("mode")
    if mode == "set":
        s["balance"] = amount
    else:
        delta = -cents(amount) if mode == "sub" else cents(amount)
        s["balance"] = max(0, cents(s["balance"]) + delta) / 100
    _save(SELLERS_FILE, sellers)
    return {"id": sid, "balance": s["balance"]}


@app.post("/api/sellers/{sid}/password", dependencies=[Depends(verify_admin)])
def seller_password(sid: str, body: Dict[str, Any] = Body(...)):
    password = str(body.get("password", ""))
    if not 4 <= len(password) <= 100:
        raise HTTPException(status_code=400, detail="Password too short")
    sellers = _load(SELLERS_FILE, [])
    s = next((x for x in sellers if x["id"] == sid), None)
    if not s:
        raise HTTPException(status_code=404, detail="Not found")
    s["pass_salt"] = secrets.token_hex(16)
    s["pass_hash"] = hash_password(password, s["pass_salt"])
    _save(SELLERS_FILE, sellers)
    _drop_sessions(lambda x: x != sid)
    return {"ok": True}


# ───────── static files (must be last) ─────────
app.mount("/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads")
if WEBSITE_DIR.exists():
    app.mount("/", StaticFiles(directory=str(WEBSITE_DIR), html=True), name="website")


# ─── POWER UP iOS App integration endpoints ──────────────────────────────────

class AppSettings(BaseModel):
    siteName:    str = "POWER UP"
    themeColor:  str = "#0a6cff"
    logoURL:     str = "logo.png"
    telegramURL: str = ""
    maintenance: bool = False
    maintenanceText: str = "Service is undergoing maintenance."
    appName:     str = "POWER UP"
    appVersion:  str = "7.0"


@app.get("/api/settings")
async def get_app_settings():
    """Returns theme/branding settings consumed by the iOS app."""
    s = _load(SETTINGS_FILE, {})
    base = AppSettings()
    return {
        "siteName":        s.get("siteName",    base.siteName),
        "themeColor":      s.get("themeColor",  base.themeColor),
        "logoURL":         s.get("logoURL",      base.logoURL),
        "telegramURL":     s.get("telegramUrl",  base.telegramURL),
        "maintenance":     s.get("maintenance",  base.maintenance),
        "maintenanceText": s.get("texts", {}).get("en", {}).get("maintenanceText", base.maintenanceText),
        "appName":         s.get("siteName",    base.appName),
        "appVersion":      "7.0",
    }


class ValidateKeyRequest(BaseModel):
    key: str


@app.post("/api/validate-key")
async def validate_key(body: ValidateKeyRequest):
    """Validate a key from the iOS app. Returns {valid: bool}."""
    keys = _load(KEYS_FILE, {})
    trimmed = body.key.strip()
    if not trimmed:
        return {"valid": False, "reason": "empty"}
    for kid, kdata in keys.items():
        if isinstance(kdata, dict) and kdata.get("key") == trimmed:
            if kdata.get("disabled"):
                return {"valid": False, "reason": "disabled"}
            exp = kdata.get("expiresAt")
            if exp:
                from datetime import datetime, timezone
                try:
                    exp_dt = datetime.fromisoformat(exp.replace("Z", "+00:00"))
                    if exp_dt < datetime.now(timezone.utc):
                        return {"valid": False, "reason": "expired"}
                except Exception:
                    pass
            return {"valid": True, "keyId": kid}
    return {"valid": False, "reason": "not_found"}
