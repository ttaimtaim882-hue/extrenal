// LicenseManager.swift — POWER UP
// Password / key screen REMOVED. App launches directly.
// Key validation goes through PowerUpAPIService if a backend URL is set.

import Combine
import Foundation
import Security

@MainActor
final class LicenseManager: ObservableObject {

    // Always active — no password gate.
    @Published private(set) var isActive: Bool = true
    @Published private(set) var isBusy:   Bool = false
    @Published private(set) var message:  String?
    @Published private(set) var expirationDate: Date?
    @Published private(set) var contactOwner:   String?
    @Published var rememberKey = true

    private let service    = "com.powerup.activation"
    private let keyAccount = "license-key"

    init() { isActive = true }

    func beginLaunchSession() {
        isActive = true
        message  = nil
    }

    // Kept for compatibility — no-op.
    func activate(key: String) {
        isActive = true
        message  = nil
    }

    func deactivate() {
        // Logout — wipes stored key and returns to onboarding / splash.
        delete(keyAccount)
        isActive = false
        message  = "Signed out"
    }

    func refresh() { isActive = true }

    func rememberedKey() -> String? { string(for: keyAccount) }

    // ── Keychain helpers ────────────────────────────────────
    private func string(for account: String) -> String? {
        let q: [String: Any] = [
            kSecClass       as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData  as String: true,
            kSecMatchLimit  as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func delete(_ account: String) {
        let q: [String: Any] = [
            kSecClass       as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(q as CFDictionary)
    }
}
