// LicenseActivationView.swift — POWER UP
// Shown ONLY when licenseManager.isActive == false (after logout).
// No password needed — just one tap to re-enter.

import SwiftUI

struct LicenseActivationView: View {
    @ObservedObject var manager: LicenseManager
    @EnvironmentObject private var api: PowerUpAPIService

    var body: some View {
        ZStack {
            PowerUpBackground()

            VStack(spacing: 32) {
                Spacer()

                // ── Logo ────────────────────────────────────
                VStack(spacing: 14) {
                    ZStack {
                        Circle()
                            .fill(AppTheme.accent.opacity(0.12))
                            .frame(width: 110, height: 110)
                            .overlay(Circle().stroke(AppTheme.accent.opacity(0.28), lineWidth: 1.5))
                            .shadow(color: AppTheme.accentGlow, radius: 24)
                        Image(systemName: "bolt.fill")
                            .font(.system(size: 48, weight: .black))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [AppTheme.accentBright, AppTheme.accent],
                                    startPoint: .top, endPoint: .bottom
                                )
                            )
                    }

                    Text(api.settings.appName.isEmpty ? "POWER UP" : api.settings.appName)
                        .font(.system(size: 32, weight: .black, design: .rounded))
                        .tracking(1.6)
                        .foregroundStyle(.white)
                        .shadow(color: AppTheme.accentGlow, radius: 8)

                    Text("v\(api.settings.appVersion)")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.45))
                }

                // ── Enter button ────────────────────────────
                Button {
                    manager.activate(key: "")
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "bolt.shield.fill")
                        Text("ENTER")
                    }
                }
                .buttonStyle(ShinyBlueButton())
                .padding(.horizontal, 32)

                Spacer()
            }
            .padding(.horizontal, 24)
        }
        .preferredColorScheme(.dark)
    }
}
