// PowerUpAPIService.swift — POWER UP
// Connects to the POWER_UP backend for settings, theme color, logo, maintenance.

import Foundation
import SwiftUI
import Combine

// ── Set your backend URL here ───────────────────────────────
// You can override at runtime from Settings or UserDefaults.
private let kAPIURLKey     = "powerup_api_url"
private let kSettingsCache = "powerup_settings_cache"

struct PowerUpSettings: Codable {
    var siteName:     String  = "POWER UP"
    var themeColor:   String  = "#0a6cff"
    var logoURL:      String  = ""
    var telegramURL:  String  = ""
    var maintenance:  Bool    = false
    var maintenanceText: String = "Service is undergoing maintenance. Please come back later."
    var appName:      String  = "POWER UP"
    var appVersion:   String  = "7.0"
}

@MainActor
final class PowerUpAPIService: ObservableObject {
    static let shared = PowerUpAPIService()

    @Published private(set) var settings = PowerUpSettings()
    @Published private(set) var themeColor: Color = AppTheme.accent
    @Published private(set) var logoURL: URL?
    @Published private(set) var isMaintenance = false
    @Published private(set) var isLoaded = false

    private var cancellables = Set<AnyCancellable>()

    init() { loadCached(); Task { await fetchSettings() } }

    // ── API base URL ────────────────────────────────────────
    var apiBase: String {
        get { UserDefaults.standard.string(forKey: kAPIURLKey) ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: kAPIURLKey) }
    }

    // ── Fetch settings from POWER UP backend ────────────────
    func fetchSettings() async {
        guard !apiBase.isEmpty,
              let url = URL(string: apiBase.trimmingCharacters(in: .whitespacesAndNewlines) + "/api/settings")
        else { return }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decoded = try JSONDecoder().decode(PowerUpSettings.self, from: data)
            settings = decoded
            apply(decoded)
            cacheSettings(data)
            isLoaded = true
        } catch {
            log("PowerUpAPI: settings fetch failed — \(error.localizedDescription)")
        }
    }

    // ── Validate key against backend ────────────────────────
    func validateKey(_ key: String) async -> Bool {
        guard !apiBase.isEmpty,
              let url = URL(string: apiBase + "/api/validate-key")
        else { return true } // no backend → accept all
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONEncoder().encode(["key": key])
        do {
            let (data, _) = try await URLSession.shared.data(for: req)
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let valid = json["valid"] as? Bool { return valid }
        } catch {}
        return true
    }

    // ── Apply decoded settings ──────────────────────────────
    private func apply(_ s: PowerUpSettings) {
        isMaintenance = s.maintenance
        if let colorURL = URL(string: s.logoURL), !s.logoURL.isEmpty {
            logoURL = colorURL
        }
        themeColor = colorFromHex(s.themeColor) ?? AppTheme.accent
    }

    // ── Cache / restore ─────────────────────────────────────
    private func cacheSettings(_ data: Data) {
        UserDefaults.standard.set(data, forKey: kSettingsCache)
    }
    private func loadCached() {
        guard let data = UserDefaults.standard.data(forKey: kSettingsCache),
              let decoded = try? JSONDecoder().decode(PowerUpSettings.self, from: data)
        else { return }
        settings = decoded
        apply(decoded)
    }

    // ── Hex → SwiftUI Color ─────────────────────────────────
    func colorFromHex(_ hex: String) -> Color? {
        var h = hex.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "#", with: "")
        if h.count == 3 { h = h.map { "\($0)\($0)" }.joined() }
        guard h.count == 6,
              let val = UInt64(h, radix: 16) else { return nil }
        return Color(
            red:   Double((val >> 16) & 0xFF) / 255,
            green: Double((val >>  8) & 0xFF) / 255,
            blue:  Double( val        & 0xFF) / 255
        )
    }
}
