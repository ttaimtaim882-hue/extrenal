// SettingsView.swift — POWER UP
// Added: shiny logout button, POWER UP branding, API URL config.

import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss)       private var dismiss
    @Environment(\.appLanguage)   private var language
    @EnvironmentObject private var appState:  AppState
    @EnvironmentObject private var license:   LicenseManager
    @EnvironmentObject private var api:       PowerUpAPIService
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue

    @State private var apiURLDraft   = ""
    @State private var showLogoutConfirm = false

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.pageBackground.ignoresSafeArea()
                Form {
                    // ── App header ───────────────────────────
                    Section {
                        HStack(spacing: 14) {
                            AppLogo(size: 46)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(api.settings.appName.isEmpty ? "POWER UP" : api.settings.appName)
                                    .font(.headline)
                                    .foregroundStyle(.white)
                                Text("v\(appVersion)")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    .listRowBackground(AppTheme.referenceCard)

                    // ── API / Backend URL ────────────────────
                    Section(header: Text("BACKEND").font(.caption.weight(.bold)).foregroundStyle(AppTheme.accent)) {
                        HStack {
                            Image(systemName: "link")
                                .foregroundStyle(AppTheme.accent)
                            TextField("https://your-server.com", text: $apiURLDraft)
                                .autocorrectionDisabled()
                                .textInputAutocapitalization(.never)
                                .keyboardType(.URL)
                                .font(.system(.body, design: .monospaced))
                                .foregroundStyle(.white)
                                .onSubmit { saveAPIURL() }
                                .submitLabel(.done)
                        }
                        Button {
                            saveAPIURL()
                            Task { await api.fetchSettings() }
                        } label: {
                            Label("Connect Backend", systemImage: "arrow.triangle.2.circlepath")
                                .foregroundStyle(AppTheme.accentBright)
                        }
                    }
                    .listRowBackground(AppTheme.referenceCard)

                    // ── Language ─────────────────────────────
                    Section(language.text("settings.language")) {
                        Picker(language.text("settings.language"), selection: $languageCode) {
                            ForEach(AppLanguage.allCases) { option in
                                Text(option.displayName).tag(option.rawValue)
                            }
                        }
                        .pickerStyle(.segmented)
                        .labelsHidden()
                    }
                    .listRowBackground(AppTheme.referenceCard)

                    // ── Device ───────────────────────────────
                    Section(language.text("common.device")) {
                        LabeledContent(language.text("dashboard.hardware_model"), value: AppInfo.displayMachineName)
                        LabeledContent(language.text("settings.ios_version"), value: "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                    }
                    .listRowBackground(AppTheme.referenceCard)

                    // ── Supported versions ───────────────────
                    Section {
                        HStack {
                            Text(language.text("settings.current_version"))
                            Spacer()
                            Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                                .foregroundStyle(appState.isSupported ? AppTheme.accentBright : AppTheme.accentRed)
                        }
                        LabeledContent("iOS 17", value: ExploitSupportPolicy.verifiedIOS17Range)
                        LabeledContent("iOS 18", value: ExploitSupportPolicy.verifiedIOS18Range)
                        LabeledContent("iOS 26", value: ExploitSupportPolicy.verifiedIOS26Range)
                        VStack(alignment: .leading, spacing: 8) {
                            Text("iOS 27.0").font(.body)
                            ForEach(ExploitSupportPolicy.verifiedIOS27Builds, id: \.build) { v in
                                Text(versionLabel(v))
                                    .font(.caption.monospaced())
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(.vertical, 2)
                    } header: {
                        Text(language.text("settings.verified_versions"))
                    } footer: {
                        Text(language.text("settings.supported_versions_footer"))
                    }
                    .listRowBackground(AppTheme.referenceCard)

                    // ── Logout ───────────────────────────────
                    Section {
                        Button(role: .destructive) {
                            showLogoutConfirm = true
                        } label: {
                            HStack {
                                Spacer()
                                Label("Sign Out", systemImage: "arrow.right.square.fill")
                                    .font(.system(size: 15, weight: .black, design: .rounded))
                                    .foregroundStyle(AppTheme.accentRed)
                                Spacer()
                            }
                            .padding(.vertical, 6)
                        }
                    }
                    .listRowBackground(
                        ZStack {
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .fill(AppTheme.accentRed.opacity(0.08))
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(AppTheme.accentRed.opacity(0.22), lineWidth: 1)
                        }
                    )
                }
                .tint(AppTheme.accent)
                .scrollContentBackground(.hidden)
                .background(AppTheme.pageBackground)
                .navigationTitle("Settings")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button(language.text("common.done")) { dismiss() }
                            .fontWeight(.semibold)
                            .foregroundStyle(AppTheme.accentBright)
                    }
                }
                .onAppear {
                    apiURLDraft = api.apiBase
                }
                .confirmationDialog("Sign out of POWER UP?",
                                    isPresented: $showLogoutConfirm,
                                    titleVisibility: .visible) {
                    Button("Sign Out", role: .destructive) {
                        dismiss()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                            license.deactivate()
                        }
                    }
                    Button("Cancel", role: .cancel) {}
                } message: {
                    Text("You'll need to open the app again to re-enter.")
                }
            }
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "7.0"
    }

    private func saveAPIURL() {
        api.apiBase = apiURLDraft.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func versionLabel(_ version: (beta: Int, publicBeta: Int?, build: String)) -> String {
        if let pb = version.publicBeta {
            return language.text("settings.developer_public_beta_build",
                                 Int64(version.beta), Int64(pb), version.build)
        }
        return language.text("settings.developer_beta_build", Int64(version.beta), version.build)
    }
}
